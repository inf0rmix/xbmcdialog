from os import getenv
XDLG_DIR = '/usr/share/xbmc/addons/script.xbmcdialog'
XBMC_USERDIR = getenv('HOME')+ '/.xbmc'
